package Mygroovy

class PageOneClass {


    public final String name;

    public PageOneClass(String name) {
        this.name = name
    }

}
