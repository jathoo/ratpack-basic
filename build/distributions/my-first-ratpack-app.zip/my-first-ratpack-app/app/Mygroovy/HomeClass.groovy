package Mygroovy
/**
 * Created by pair-5 on 23/11/16.
 */
class HomeClass {

    public String transformName(name) {
        def myName = name + 'transformed'
        myName
    }
}
