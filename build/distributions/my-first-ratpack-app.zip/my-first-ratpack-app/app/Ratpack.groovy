import handlers.ApiHandler
import ratpack.groovy.template.MarkupTemplateModule

import static ratpack.groovy.Groovy.groovyMarkupTemplate
import static ratpack.groovy.Groovy.ratpack

ratpack {
  bindings {
    module MarkupTemplateModule
    bindInstance(InjectionClass, new InjectionClass())
  }

  handlers { InjectionClass injectionClass ->
    get {
      render groovyMarkupTemplate("index.gtpl", title: "My Ratpack App")
    }

    prefix("api") {
      path ("getMyData") {
        def name = injectionClass.transformName("Yathu")
        render(name)
      }
    }

    files { dir "public" }
  }
}
