package handlers

import ratpack.handling.Context
import ratpack.handling.InjectionHandler


class ApiHandler extends InjectionHandler{

    void handle(Context ctx, InjectionClass injectionClass) {
        ctx.render("this is my handler")
    }
}
